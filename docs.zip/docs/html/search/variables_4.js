var searchData=
[
  ['observerlist_0',['observerList',['../classSubject.html#a05a469357fee779f8748bde5be78bed5',1,'Subject']]]
];
