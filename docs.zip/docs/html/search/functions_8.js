var searchData=
[
  ['notify_0',['notify',['../classSubject.html#ac8138b1a3a5268053640c11c2090827d',1,'Subject']]]
];
