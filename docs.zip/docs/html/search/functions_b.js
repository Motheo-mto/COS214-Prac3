var searchData=
[
  ['setcapacity_0',['setCapacity',['../classEventComponent.html#a3c6525a6534b26ba400373971ff09946',1,'EventComponent']]],
  ['setname_1',['setName',['../classEventComponent.html#a98722ec5c5ed180c7e34bab5828c61f7',1,'EventComponent']]],
  ['setsheltered_2',['setSheltered',['../classStage.html#ac8c6f46945318e965b34447354e0f006',1,'Stage']]],
  ['stage_3',['Stage',['../classStage.html#a81f5f991cdf4e5b78cb06cdfa805cc5e',1,'Stage::Stage()'],['../classStage.html#a9aeec58fb4f16ac649e24a081c1fc036',1,'Stage::Stage(string name, int capacity)']]]
];
