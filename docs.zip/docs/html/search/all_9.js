var searchData=
[
  ['name_0',['name',['../classEventComponent.html#a834c7802d7cc8af6b68a604f0a4529e4',1,'EventComponent']]],
  ['notify_1',['notify',['../classSubject.html#ac8138b1a3a5268053640c11c2090827d',1,'Subject']]]
];
