var searchData=
[
  ['stocklevel_0',['stockLevel',['../classMerch.html#abb891518bd49f1b0cf744faf5ce985b6',1,'Merch']]]
];
