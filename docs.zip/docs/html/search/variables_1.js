var searchData=
[
  ['foodleft_0',['foodLeft',['../classFood.html#a225cc89ed5194a246e527070df294dcd',1,'Food']]]
];
