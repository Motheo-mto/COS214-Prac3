var searchData=
[
  ['isopen_0',['isOpen',['../classEventUnit.html#a20d256580f9b879b6dcf8b5e1ba4103c',1,'EventUnit']]],
  ['issheltered_1',['isSheltered',['../classStage.html#a43057a9752fe49994efadd34889831b1',1,'Stage']]]
];
