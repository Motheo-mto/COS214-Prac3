var indexSectionsWithContent =
{
  0: "abcdefgimnoprsu~",
  1: "befgmos",
  2: "befgmors",
  3: "abcdefgmnorsu~",
  4: "cfinops",
  5: "cp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

