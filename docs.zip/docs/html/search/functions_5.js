var searchData=
[
  ['food_0',['Food',['../classFood.html#a75d4d7f76fd495cc8133302ca9fdc485',1,'Food::Food()'],['../classFood.html#a3b8ee478717396ca9442bd022aacba33',1,'Food::Food(string name, int capacity)']]]
];
