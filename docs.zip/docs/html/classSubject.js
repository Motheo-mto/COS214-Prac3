var classSubject =
[
    [ "~Subject", "classSubject.html#a7c4f522850f718466e5be7eb55ba1969", null ],
    [ "attach", "classSubject.html#a0884bfe374d352c6488a1e40c84246c8", null ],
    [ "detach", "classSubject.html#a752a7596d52ab986539232f8377ca92c", null ],
    [ "notify", "classSubject.html#ac8138b1a3a5268053640c11c2090827d", null ],
    [ "observerList", "classSubject.html#a05a469357fee779f8748bde5be78bed5", null ]
];