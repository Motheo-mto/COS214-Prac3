var classObserver =
[
    [ "~Observer", "classObserver.html#a37824643eeaef086de17bba2717d865a", null ],
    [ "update", "classObserver.html#a7ba2a589be8ed061f0ce5031d2a45dec", null ]
];