var hierarchy =
[
    [ "Observer", "classObserver.html", [
      [ "EventGroup", "classEventGroup.html", null ],
      [ "EventUnit", "classEventUnit.html", [
        [ "Bathroom", "classBathroom.html", null ],
        [ "Food", "classFood.html", null ],
        [ "Gate", "classGate.html", null ],
        [ "Merch", "classMerch.html", null ],
        [ "Stage", "classStage.html", null ]
      ] ]
    ] ],
    [ "Subject", "classSubject.html", [
      [ "EventComponent", "classEventComponent.html", [
        [ "EventGroup", "classEventGroup.html", null ],
        [ "EventUnit", "classEventUnit.html", null ]
      ] ]
    ] ]
];