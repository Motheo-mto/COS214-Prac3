var classEventGroup =
[
    [ "EventGroup", "classEventGroup.html#a8d5e797dbd7a2f10435198ae964511aa", null ],
    [ "EventGroup", "classEventGroup.html#a7db81620859148e539d73b62bb61fc09", null ],
    [ "~EventGroup", "classEventGroup.html#aec45fca847056b3ea8b62899c5903f55", null ],
    [ "add", "classEventGroup.html#a90ec9c50da1b72af0021ce4aca29d4a4", null ],
    [ "close", "classEventGroup.html#a600460d78e6fc8d0ec13b1767590dcc9", null ],
    [ "getCapacity", "classEventGroup.html#affe035069afc221547fe9e848017ee3c", null ],
    [ "open", "classEventGroup.html#aa12055a0456c9e6faf6de3a12a70b0e1", null ],
    [ "remove", "classEventGroup.html#a91eaf40c120aa49ae20e5da6ec742679", null ],
    [ "reportStatus", "classEventGroup.html#abc6919ac70ecf081cdec8c3ffaadc89e", null ],
    [ "update", "classEventGroup.html#a25abd370f2a0615e94781f3472029c37", null ],
    [ "children", "classEventGroup.html#ac6d6c40dba1e730ae47cc2d1b95e7663", null ]
];