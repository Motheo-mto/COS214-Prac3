var classFood =
[
    [ "Food", "classFood.html#a75d4d7f76fd495cc8133302ca9fdc485", null ],
    [ "Food", "classFood.html#a3b8ee478717396ca9442bd022aacba33", null ],
    [ "~Food", "classFood.html#a6f25dffd1fb347c982a53b9a384c611a", null ],
    [ "close", "classFood.html#a3cdd7ef5f3a8e31548ead9f26034c24f", null ],
    [ "getCapacity", "classFood.html#a883b7039c686d124c1304d94b573487f", null ],
    [ "open", "classFood.html#a2cb08567a091bffc8915575dc0fa72ec", null ],
    [ "reportStatus", "classFood.html#aedd0f90953334633ec63447f8bf1ab25", null ],
    [ "update", "classFood.html#a02d3012f74df298a4b9402eebc5e2a2a", null ],
    [ "foodLeft", "classFood.html#a225cc89ed5194a246e527070df294dcd", null ],
    [ "previousCapacity", "classFood.html#a884d6aa838bf1ef29dc586becd9a0e0d", null ]
];