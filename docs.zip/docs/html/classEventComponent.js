var classEventComponent =
[
    [ "EventComponent", "classEventComponent.html#aac68ab2c73ea6c329042b67d07060256", null ],
    [ "EventComponent", "classEventComponent.html#a7957cead4312d0f6c3486403676bf1e4", null ],
    [ "~EventComponent", "classEventComponent.html#ab4089b4d2e6d93f57fe8da0736a33872", null ],
    [ "add", "classEventComponent.html#ad675408a0df376b342a28e7ce02d5563", null ],
    [ "close", "classEventComponent.html#a8e13a68d681c1b6affcf13435a09adab", null ],
    [ "getCapacity", "classEventComponent.html#a3bb6f9718c8c945f2b95ea7a471bd6d6", null ],
    [ "getName", "classEventComponent.html#aad2fdf9c535b9b976e2873916d51b017", null ],
    [ "open", "classEventComponent.html#ada5f41377769e0cbdaa7546477b3970c", null ],
    [ "remove", "classEventComponent.html#a6c1204d268508a8aaa8dfcdba0cbf568", null ],
    [ "reportStatus", "classEventComponent.html#a625b1459850d5a94793c54404a280231", null ],
    [ "setCapacity", "classEventComponent.html#a3c6525a6534b26ba400373971ff09946", null ],
    [ "setName", "classEventComponent.html#a98722ec5c5ed180c7e34bab5828c61f7", null ],
    [ "capacity", "classEventComponent.html#ae4b041c98bc58d53783231ae2e8f626b", null ],
    [ "name", "classEventComponent.html#a834c7802d7cc8af6b68a604f0a4529e4", null ]
];