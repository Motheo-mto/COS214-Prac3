var classStage =
[
    [ "Stage", "classStage.html#a81f5f991cdf4e5b78cb06cdfa805cc5e", null ],
    [ "Stage", "classStage.html#a9aeec58fb4f16ac649e24a081c1fc036", null ],
    [ "~Stage", "classStage.html#af769a51df1efaaa5fca98008fb6f0c16", null ],
    [ "close", "classStage.html#a461c1b3dd2f0cb6681b136e9b3533b46", null ],
    [ "getCapacity", "classStage.html#adc848453c0f900328c04eff299d8298c", null ],
    [ "open", "classStage.html#a7ca798fafa7751792ccd5677e1ea260c", null ],
    [ "reportStatus", "classStage.html#aec87226b96fab2657c3f4242df6d7728", null ],
    [ "setSheltered", "classStage.html#ac8c6f46945318e965b34447354e0f006", null ],
    [ "update", "classStage.html#a6c31bbdcffaa999e8118cdad1e8e07b7", null ],
    [ "isSheltered", "classStage.html#a43057a9752fe49994efadd34889831b1", null ]
];