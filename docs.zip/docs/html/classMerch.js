var classMerch =
[
    [ "Merch", "classMerch.html#aeb509b03e773699d9ae0d8c9f43bc081", null ],
    [ "Merch", "classMerch.html#a83f6653da7e391609c72544665099857", null ],
    [ "~Merch", "classMerch.html#a8ed2724e3aa486b7599d715f2cf6d6b5", null ],
    [ "close", "classMerch.html#a37631e74bdb93e7b01f411faff7013f8", null ],
    [ "getCapacity", "classMerch.html#a6edd45571ec9e371f8ecb7efbfdb795a", null ],
    [ "open", "classMerch.html#a543d4e3c167d392de14c064578a71922", null ],
    [ "reportStatus", "classMerch.html#afb2d22b9041fc72d71fb994e785d5ae3", null ],
    [ "update", "classMerch.html#add664fe84da144f10e968e94c8f623d1", null ],
    [ "previousCapacity", "classMerch.html#a389b1bb5a235ecf93ce9e4bd68e6b3da", null ],
    [ "stockLevel", "classMerch.html#abb891518bd49f1b0cf744faf5ce985b6", null ]
];